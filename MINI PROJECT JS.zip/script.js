function cekNilai() {
  const input = document.getElementById("inputNilai").value;
  const hasil = document.getElementById("hasil");
  const nilai = Number(input);

  // Tugas tambahan 1: validasi input kosong / di luar 0 - 100
  if (input === "" || nilai < 0 || nilai > 100) {
    hasil.textContent = "Masukkan nilai antara 0 sampai 100!";
    return;
  }

  // Menentukan nilai huruf
  let huruf;
  if (nilai >= 90) {
    huruf = "A";
  } else if (nilai >= 80) {
    huruf = "B";
  } else if (nilai >= 70) {
    huruf = "C";
  } else {
    huruf = "D";
  }

  // Tugas tambahan 2: keterangan menggunakan switch
  let keterangan;
  switch (huruf) {
    case "A":
      keterangan = "Sangat Baik";
      break;
    case "B":
      keterangan = "Baik";
      break;
    case "C":
      keterangan = "Cukup";
      break;
    default:
      keterangan = "Perlu belajar lagi";
  }

  hasil.textContent = "Nilai huruf: " + huruf + " (" + keterangan + ")";
}

// Tantangan: cek tahun kabisat
function cekKabisat() {
  const input = document.getElementById("inputTahun").value;
  const hasil = document.getElementById("hasilKabisat");
  const tahun = Number(input);

  if (input === "" || tahun <= 0) {
    hasil.textContent = "Masukkan tahun yang valid!";
    return;
  }

  if ((tahun % 4 === 0 && tahun % 100 !== 0) || tahun % 400 === 0) {
    hasil.textContent = tahun + " adalah tahun kabisat";
  } else {
    hasil.textContent = tahun + " bukan tahun kabisat";
  }
}